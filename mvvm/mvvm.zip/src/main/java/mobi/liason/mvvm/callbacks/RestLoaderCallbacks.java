package mobi.liason.mvvm.callbacks;

import android.app.LoaderManager;
import android.app.LoaderManager.LoaderCallbacks;
import android.content.Context;
import android.content.Loader;
import android.content.Loader.ForceLoadContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import mobi.liason.mvvm.loaders.RestCursorLoader;

/**
 * Created by Emir Hasanbegovic on 18/04/14.
 */
public abstract class RestLoaderCallbacks implements LoaderCallbacks<Cursor> {

    private final RestLoaderCallbacksListener mRestLoaderCallbacksListener;
    private final Context mContext;
    private LoaderManager mLoaderManager;
    private ForceLoadContentObserver mForceLoadContentObserver;

    public RestLoaderCallbacks(final Context context, final LoaderManager loaderManager, final RestLoaderCallbacksListener restLoaderCallbacksListener) {
        mLoaderManager = loaderManager;
        mRestLoaderCallbacksListener = restLoaderCallbacksListener;
        mContext = context;
    }

    public abstract Uri getUri();

    public abstract int getLoaderId();

    public String[] getProjection() {
        return null;
    }

    public String getSelection() {
        return null;
    }

    public String[] getSelectionArguments() {
        return null;
    }

    public String getSortOrder() {
        return null;
    }

    @Override
    public Loader<Cursor> onCreateLoader(final int id, final Bundle args) {
        final Uri uri = getUri();
        final RestCursorLoader restCursorLoader = new RestCursorLoader(mContext, uri, getProjection(), getSelection(), getSelectionArguments(), getSortOrder());
        restCursorLoader.setUri(uri);
        mForceLoadContentObserver = (ForceLoadContentObserver) restCursorLoader.getForceLoadContentObserver();
        mContext.getContentResolver().registerContentObserver(uri, false, mForceLoadContentObserver);
        return restCursorLoader;
    }

    @Override
    public void onLoadFinished(final Loader<Cursor> loader, final Cursor cursor) {
        cursor.moveToFirst();
        mRestLoaderCallbacksListener.onLoadFinished(getUri(), cursor);
    }

    @Override
    public void onLoaderReset(final Loader<Cursor> loader) {
        mRestLoaderCallbacksListener.onLoaderReset(loader);
    }

    public void onStart(final Context context) {
        final Loader<?> loader = mLoaderManager.getLoader(getLoaderId());
        if (loader == null)
            mLoaderManager.initLoader(getLoaderId(), null, this);
        else
            mLoaderManager.restartLoader(getLoaderId(), null, this);
    }

    public void onStop(final Context context) {
        if (mForceLoadContentObserver != null)
            mContext.getContentResolver().unregisterContentObserver(mForceLoadContentObserver);
    }

}